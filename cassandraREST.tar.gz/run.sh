#!/bin/sh

SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/cassandraREST.exe" -importPath cassandraREST -srcPath "$SCRIPTPATH/src" -runMode dev
