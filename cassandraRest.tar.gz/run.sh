#!/bin/sh

SCRIPTPATH=$(cd "$(dirname "$0")"; pwd)
"$SCRIPTPATH/cassandraRest.exe" -importPath cassandraRest -srcPath "$SCRIPTPATH/src" -runMode dev
